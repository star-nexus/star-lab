import subprocess,hashlib,os,json
from pathlib import Path
s=Path('/Users/liyang/.codex/worktrees/rust-ecs-parallel/star-main');lab=Path('/Users/liyang/Developer/star-lab');run=lab/'runs/ecs-e5';python=str(s/'.venv/bin/python');tool=lab/'tools/rust_migration/profile_movement_visuals.py';env=dict(os.environ,HEADLESS='1',SDL_VIDEODRIVER='dummy',PYGAME_HIDE_SUPPORT_PROMPT='1')
new=next((s/'.venv/lib/python3.13/site-packages/star_native').glob('*.so'));newsha=hashlib.sha256(new.read_bytes()).hexdigest();source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();inputs=lab/'runs/ecs-e3-reproduction/inputs';trace=inputs/'rust-300-r3.trace.json.gz'
base=[python,str(tool),'--source',str(s),'--trace',str(trace),'--trace-sha256',hashlib.sha256(trace.read_bytes()).hexdigest(),'--source-sha',source,'--extension-sha256',newsha]
commands=[]
def replay(name,args):
    output=run/f'replays/{name}.json';output.parent.mkdir(parents=True,exist_ok=True)
    argv=base+['--output',str(output)]+args;commands.append(argv);(run/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    with output.with_suffix('.log').open('w') as log:subprocess.run(argv,check=True,env=env,stdout=log,stderr=subprocess.STDOUT)
    print('COMPLETE',name,flush=True)
# Independent original E4 oracle is preserved separately; this unprofiled
# split replay must match its canonical response/delta stream and final state.
replay('split-serial-t1',['--threads','1','--mode','compare','--probe-mode','split_serial','--min-damage-rows','0'])
for t in [2,4]:
    for r in range(1,4):
        replay(f'primary-t{t}-r{r}',['--threads',str(t),'--mode','plain','--probe-mode','parallel','--paired'])
        replay(f'split-control-t{t}-r{r}',['--threads',str(t),'--mode','plain','--probe-mode','parallel','--paired','--control-mode','split_serial','--control-min-damage-rows','8'])
for t in [2,4]:
    for mode in ['baseline','empty_fork','split_serial','parallel']:
        replay(f'diagnostic-{mode}-t{t}',['--threads',str(t),'--mode','compare','--probe-mode',mode])
    for threshold in [0,4,16]:
        replay(f'sensitivity-{threshold}-t{t}',['--threads',str(t),'--mode','plain','--probe-mode','parallel','--paired','--min-damage-rows',str(threshold)])
subprocess.run([python,str(lab/'tools/rust_migration/analyze_movement_visuals.py'),'--runs',str(run/'replays'),'--output',str(run/'analysis.json')],check=True,env=env)
