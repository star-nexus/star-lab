use pyo3::{
    exceptions::{PyRuntimeError, PyValueError},
    prelude::*,
};
use serde_json::{Value, json};
use star_rotk::observation::ReadSegmentCache;
use star_rotk::runtime::Runtime;
use std::sync::{
    Mutex,
    atomic::{AtomicU64, Ordering},
};

static INSTANCE_NONCE: AtomicU64 = AtomicU64::new(1);

struct ReadSegment {
    token: String,
    owner: std::thread::ThreadId,
    epoch: u64,
    requests: usize,
    maximum: usize,
    reuse: bool,
    cache: Option<ReadSegmentCache>,
    diagnostics: Option<Vec<Value>>,
}
struct NativeState {
    runtime: Option<Runtime>,
    segment: Option<ReadSegment>,
    nonce: u64,
    generation: u64,
}
impl NativeState {
    fn invalidate_read_segment(&mut self) {
        self.segment = None;
        // Saturation disables future research segments; ordinary operations
        // remain available. No generation can wrap and revive an old token.
        self.generation = self.generation.saturating_add(1);
    }
}

fn check_control_epoch(runtime: &Runtime, expected: Option<u64>) -> Result<(), String> {
    if expected.is_some_and(|epoch| epoch != runtime.epoch) {
        return Err("local control epoch changed; prepare new scene controls".into());
    }
    Ok(())
}

/// Owned Rust world. The lock is always acquired after detaching from Python.
/// A poisoned instance errors permanently; no recovery into a different world.
#[pyclass(frozen, module = "star_native._native")]
struct NativeRuntime {
    inner: Mutex<NativeState>,
}

impl NativeRuntime {
    fn with_state<T: Send>(
        &self,
        py: Python<'_>,
        f: impl FnOnce(&mut NativeState) -> Result<T, String> + Send,
    ) -> PyResult<T> {
        py.detach(|| {
            let mut guard = self
                .inner
                .lock()
                .map_err(|_| "native runtime is poisoned".to_string())?;
            f(&mut guard)
        })
        .map_err(PyRuntimeError::new_err)
    }
    fn with_runtime<T: Send>(
        &self,
        py: Python<'_>,
        f: impl FnOnce(&mut Runtime) -> Result<T, String> + Send,
    ) -> PyResult<T> {
        self.with_state(py, |state| {
            // Every ordinary native entry, including reads and failed input
            // decoding, is a conservative barrier before touching Runtime.
            state.invalidate_read_segment();
            let runtime = state.runtime.as_mut().ok_or("native runtime is closed")?;
            f(runtime)
        })
    }
}

#[pymethods]
impl NativeRuntime {
    #[new]
    #[pyo3(signature=(scene_json, threads=1))]
    fn new(py: Python<'_>, scene_json: String, threads: usize) -> PyResult<Self> {
        let world = py
            .detach(|| Runtime::from_json(&scene_json, threads, 1))
            .map_err(PyValueError::new_err)?;
        Ok(Self {
            inner: Mutex::new(NativeState {
                runtime: Some(world),
                segment: None,
                generation: 0,
                nonce: INSTANCE_NONCE
                    .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
                    .map_err(|_| PyRuntimeError::new_err("instance nonce exhausted"))?,
            }),
        })
    }
    fn reset(&self, py: Python<'_>, scene_json: String) -> PyResult<()> {
        self.with_runtime(py, |runtime| runtime.reset(&scene_json))
    }
    fn step(&self, py: Python<'_>, dt: f64, wall_time: f64) -> PyResult<()> {
        self.with_runtime(py, |r| r.step(dt, wall_time))
    }
    /// Opt-in advancing profiler; normal step performs no timer reads.
    fn _step_profile_json(&self, py: Python<'_>, dt: f64, wall_time: f64) -> PyResult<String> {
        self.with_runtime(py, |r| Ok(r.profile_step(dt, wall_time)?.to_string()))
    }
    #[pyo3(signature=(dt, wall_time, mode, min_damage_rows=8, profile=false))]
    fn _movement_visuals_step_json(
        &self,
        py: Python<'_>,
        dt: f64,
        wall_time: f64,
        mode: &str,
        min_damage_rows: usize,
        profile: bool,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            Ok(
                r.movement_visuals_step_probe(dt, wall_time, mode, min_damage_rows, profile)?
                    .to_string(),
            )
        })
    }
    /// E4 private per-call negative control; never persists an execution policy.
    #[pyo3(signature=(dt, wall_time, mode, profile=false))]
    fn _between_systems_step_json(
        &self,
        py: Python<'_>,
        dt: f64,
        wall_time: f64,
        mode: &str,
        profile: bool,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            Ok(r.between_systems_step_probe(dt, wall_time, mode, profile)?
                .to_string())
        })
    }
    /// Advancing research control; overrides only this call's pure-row dispatch.
    #[pyo3(signature=(dt, wall_time, min_rows, profile=true))]
    fn _statistics_step_json(
        &self,
        py: Python<'_>,
        dt: f64,
        wall_time: f64,
        min_rows: usize,
        profile: bool,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            Ok(r.statistics_step_probe(dt, wall_time, min_rows, profile)?
                .to_string())
        })
    }
    #[pyo3(signature=(expected_epoch=None))]
    fn host_status_json(&self, py: Python<'_>, expected_epoch: Option<u64>) -> PyResult<String> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            Ok(r.host_status().to_string())
        })
    }
    #[pyo3(signature=(agent_id, expected_epoch=None))]
    fn record_message(
        &self,
        py: Python<'_>,
        agent_id: Option<String>,
        expected_epoch: Option<u64>,
    ) -> PyResult<()> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            r.record_message(agent_id.as_deref())
        })
    }
    #[pyo3(signature=(wall_time, expected_epoch=None))]
    fn turn_start_context_json(
        &self,
        py: Python<'_>,
        wall_time: f64,
        expected_epoch: Option<u64>,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            Ok(r.turn_start_context(wall_time)?.to_string())
        })
    }
    #[pyo3(signature=(connected_agents, wall_time, expected_epoch=None))]
    fn prepare_game_end_json(
        &self,
        py: Python<'_>,
        connected_agents: Vec<String>,
        wall_time: f64,
        expected_epoch: Option<u64>,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            Ok(r.prepare_game_end(&connected_agents, wall_time)?
                .to_string())
        })
    }
    /// Local Framework input only. Never dispatch Protocol/Agent payloads here.
    #[pyo3(signature=(command_json, wall_time, expected_epoch=None))]
    fn execute_control_json(
        &self,
        py: Python<'_>,
        command_json: String,
        wall_time: f64,
        expected_epoch: Option<u64>,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            let command = serde_json::from_str(&command_json).map_err(|e| e.to_string())?;
            Ok(r.execute_control(command, wall_time)?.to_string())
        })
    }
    /// Trusted Framework keyboard/menu input; not an Agent wire verb.
    #[pyo3(signature=(wall_time, expected_epoch=None))]
    fn finish_human_turn(
        &self,
        py: Python<'_>,
        wall_time: f64,
        expected_epoch: Option<u64>,
    ) -> PyResult<()> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            r.finish_human_turn(wall_time)
        })
    }
    /// Trusted Framework input for the window's timed capture operation.
    #[pyo3(signature=(unit_id, position, wall_time, expected_epoch=None))]
    fn start_capture(
        &self,
        py: Python<'_>,
        unit_id: u64,
        position: (i64, i64),
        wall_time: f64,
        expected_epoch: Option<u64>,
    ) -> PyResult<bool> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            r.start_capture(unit_id, position, wall_time)
        })
    }
    fn set_clock(&self, py: Python<'_>, paused: bool, time_scale: f64) -> PyResult<()> {
        self.with_runtime(py, |r| r.set_clock(paused, time_scale))
    }
    fn _set_wall_metadata(&self, py: Python<'_>, wall_time: f64) -> PyResult<()> {
        self.with_runtime(py, |r| r.set_wall_metadata(wall_time))
    }
    #[pyo3(signature=(expected_epoch=None))]
    fn export_state_json(&self, py: Python<'_>, expected_epoch: Option<u64>) -> PyResult<String> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            serde_json::to_string(&r.export()).map_err(|e| e.to_string())
        })
    }
    fn diagnostics_json(&self, py: Python<'_>) -> PyResult<String> {
        self.with_runtime(py, |r| Ok(r.diagnostics().to_string()))
    }
    #[pyo3(signature=(expected_epoch=None))]
    fn take_presentation_delta_json(
        &self,
        py: Python<'_>,
        expected_epoch: Option<u64>,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            check_control_epoch(r, expected_epoch)?;
            serde_json::to_string(&r.presentation()).map_err(|e| e.to_string())
        })
    }
    fn close(&self, py: Python<'_>) -> PyResult<()> {
        self.with_state(py, |state| {
            state.invalidate_read_segment();
            state.runtime.take();
            Ok(())
        })
    }
    /// Private research lifetime; does not write world clock or action counts.
    #[pyo3(signature=(mode, max_requests=4, diagnostics=false))]
    fn _begin_observation_segment_json(
        &self,
        py: Python<'_>,
        mode: String,
        max_requests: usize,
        diagnostics: bool,
    ) -> PyResult<Option<String>> {
        if !matches!(mode.as_str(), "segment_no_reuse" | "segment_encoded")
            || !(2..=4).contains(&max_requests)
        {
            return Err(PyValueError::new_err(
                "invalid observation segment mode or limit",
            ));
        }
        self.with_state(py, |state| {
            let r = state.runtime.as_ref().ok_or("native runtime is closed")?;
            if state.segment.is_some() {
                return Err("observation segment already active".into());
            }
            if !r.admitted_faction_query_is_readonly() {
                return Ok(None);
            }
            state.generation = state
                .generation
                .checked_add(1)
                .ok_or("segment generation exhausted")?;
            let token = format!("{}:{}:{}", state.nonce, r.epoch, state.generation);
            state.segment = Some(ReadSegment {
                token: token.clone(),
                owner: std::thread::current().id(),
                epoch: r.epoch,
                requests: 0,
                maximum: max_requests,
                reuse: mode == "segment_encoded",
                cache: Some(ReadSegmentCache::default()),
                diagnostics: diagnostics.then(Vec::new),
            });
            Ok(Some(token))
        })
    }
    /// A stale token falls back before any request side effect, never retries.
    fn _observation_segment_request_json(
        &self,
        py: Python<'_>,
        token: String,
        request_json: String,
    ) -> PyResult<String> {
        self.with_state(py, |state| {
            let request: star_rotk::actions::Request = match serde_json::from_str(&request_json) {
                Ok(r) => r,
                Err(e) => {
                    state.invalidate_read_segment();
                    return Err(e.to_string());
                }
            };
            let r = state.runtime.as_mut().ok_or("native runtime is closed")?;
            let valid = state.segment.as_ref().is_some_and(|s| {
                s.token == token
                    && s.owner == std::thread::current().id()
                    && s.epoch == r.epoch
                    && s.requests < s.maximum
            }) && request.action.as_deref() == Some("get_faction_state")
                && r.admitted_faction_query_is_readonly();
            if !valid {
                // End the active cache even when the provided token is old:
                // ordinary fallback is itself a conservative native barrier.
                state.segment = None;
                state.generation = state.generation.saturating_add(1);
                return e8_encode(&r.execute_request(request)?)
                    .map_err(|e| e.to_string());
            }
            // Move the entire owned context out: any error/panic drops it;
            // no partially executed request can be replayed or cached later.
            let mut segment = state.segment.take().expect("valid active segment");
            if !segment.reuse {
                segment.cache = Some(ReadSegmentCache::default());
            }
            let mut diagnostic = Value::Null;
            let diagnostic_agent = segment
                .diagnostics
                .as_ref()
                .and_then(|_| request.agent_id.clone());
            let response = r.execute_request_with_read_cache(
                request,
                &mut segment.cache,
                segment.diagnostics.as_ref().map(|_| &mut diagnostic),
            )?;
            let encoded = e8_encode(&response).map_err(|e| e.to_string())?;
            segment.requests += 1;
            if let Some(rows) = &mut segment.diagnostics {
                diagnostic["accounting_after_request"] =
                    r.admitted_query_accounting_snapshot(diagnostic_agent.as_deref());
                rows.push(diagnostic);
            }
            // All responses own immutable backing; they do not borrow cache.
            state.segment = Some(segment);
            Ok(encoded)
        })
    }
    /// Ending an old/foreign token must never destroy a newer active context.
    fn _end_observation_segment_json(
        &self,
        py: Python<'_>,
        token: String,
    ) -> PyResult<Option<String>> {
        self.with_state(py, |state| {
            if !state.segment.as_ref().is_some_and(|s| s.token==token && s.owner==std::thread::current().id()) {
                return Ok(None);
            }
            let segment = state.segment.take().expect("matching segment");
            segment.diagnostics.map(|rows| serde_json::to_string(&json!({
                "requests":segment.requests,"query_diagnostics":rows,
                "cache_before_drop":segment.cache.as_ref().map(ReadSegmentCache::diagnostic_summary),
            })).map_err(|e| e.to_string())).transpose()
        })
    }
    /// Internal differential harness, never advertised as an Agent action gate.
    fn _vision_probe_json(&self, py: Python<'_>, operations_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let ops: Vec<Value> =
                serde_json::from_str(&operations_json).map_err(|e| e.to_string())?;
            let mut results = Vec::new();
            for op in ops {
                let revision = r.revision.checked_add(1).ok_or("revision exhausted")?;
                let result = r.vision_probe(&op);
                r.revision = revision;
                results.push(result?);
            }
            Ok(json!(results).to_string())
        })
    }
    /// Internal differential harness, never advertised as an Agent action gate.
    fn _combat_probe_json(&self, py: Python<'_>, operations_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let ops: Vec<Value> =
                serde_json::from_str(&operations_json).map_err(|e| e.to_string())?;
            let mut results = Vec::new();
            for op in ops {
                let id = op["unit_id"].as_u64().ok_or("invalid unit_id")?;
                let target = op["target_id"].as_u64();
                let result = match op["kind"].as_str() {
                    Some("ready") => json!(r.can_attack(id, target)),
                    Some("effective") => json!(r.effective_stats(id)?),
                    Some("attack") => {
                        let revision = r.revision.checked_add(1).ok_or("revision exhausted")?;
                        let result = r.execute_attack(id, target.ok_or("missing target")?);
                        // Partial execution still invalidates all read contexts.
                        r.revision = revision;
                        result?
                    }
                    _ => return Err("unknown combat probe".into()),
                };
                results.push(result);
            }
            Ok(json!(results).to_string())
        })
    }
    /// Trusted local ingress. agent_id is supplied by the Python/Protocol adapter.
    fn execute_action_json(&self, py: Python<'_>, request_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let request = serde_json::from_str(&request_json).map_err(|e| e.to_string())?;
            e8_encode(&r.execute_request(request)?).map_err(|e| e.to_string())
        })
    }
    /// Decode a complete batch before the Python host splits at display reads.
    /// Keep malformed envelopes atomic even when later entries require a frame.
    fn _validate_requests_json(&self, py: Python<'_>, requests_json: String) -> PyResult<()> {
        self.with_runtime(py, |_| {
            let requests: Vec<star_rotk::actions::Request> =
                serde_json::from_str(&requests_json).map_err(|e| e.to_string())?;
            if requests
                .iter()
                .any(|request| !request.wall_time.is_finite())
            {
                return Err("wall metadata must be finite".into());
            }
            Ok(())
        })
    }
    /// Ordered requests; consecutive faction queries share a borrowed read context.
    /// Envelope decoding is atomic; execution is sequential, not a transaction.
    fn execute_actions_json(&self, py: Python<'_>, requests_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let requests = serde_json::from_str(&requests_json).map_err(|e| e.to_string())?;
            serde_json::to_string(&r.execute_requests(requests)?).map_err(|e| e.to_string())
        })
    }
    /// Internal component probe; does not authorize Agent actions.
    fn _team_probe_json(&self, py: Python<'_>, operations_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let ops: Vec<Value> =
                serde_json::from_str(&operations_json).map_err(|e| e.to_string())?;
            Ok(json!(r.team_probe(ops)?).to_string())
        })
    }
    /// Handler-level differential probe, not the authenticated Agent interface.
    fn _observation_probe_json(&self, py: Python<'_>, parameters_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let requests: Vec<Value> =
                serde_json::from_str(&parameters_json).map_err(|e| e.to_string())?;
            let mut batch = star_rotk::observation::ObservationBatch::new(r);
            let results: Vec<_> = requests.iter().map(|p| batch.faction_state(p)).collect();
            let report = star_rotk::observation::ObservationReport {
                results,
                metrics: batch.metrics,
            };
            serde_json::to_string(&report).map_err(|e| e.to_string())
        })
    }
    /// Opt-in handler profiler. Returns the ordinary report and separate timings.
    /// This is not an authenticated Agent gate; normal calls do not read timers.
    fn _observation_profile_json(
        &self,
        py: Python<'_>,
        parameters_json: String,
    ) -> PyResult<(String, String)> {
        self.with_runtime(py, |r| {
            use std::time::Instant;
            let total = Instant::now();
            let requests: Vec<Value> =
                serde_json::from_str(&parameters_json).map_err(|e| e.to_string())?;
            let parse_ns = total.elapsed().as_nanos() as u64;
            let start = Instant::now();
            let mut batch = star_rotk::observation::ObservationBatch::profiled(r);
            let results: Vec<_> = requests.iter().map(|p| batch.faction_state(p)).collect();
            let batch_ns = start.elapsed().as_nanos() as u64;
            let profile = batch.profile.take();
            let report = star_rotk::observation::ObservationReport {
                results,
                metrics: std::mem::take(&mut batch.metrics),
            };
            let start = Instant::now();
            let encoded = serde_json::to_string(&report).map_err(|e| e.to_string())?;
            let final_encode_ns = start.elapsed().as_nanos() as u64;
            let start = Instant::now();
            drop(report);
            drop(batch);
            drop(requests);
            let drop_ns = start.elapsed().as_nanos() as u64;
            let native_ns = total.elapsed().as_nanos() as u64;
            let timing = json!({"parse_ns":parse_ns,"batch_ns":batch_ns,"profile":profile,
                "final_encode_ns":final_encode_ns,"drop_ns":drop_ns,"native_ns":native_ns});
            Ok((encoded, timing.to_string()))
        })
    }
    /// Internal differential harness, never advertised as an Agent action gate.
    fn _resource_probe_json(&self, py: Python<'_>, operations_json: String) -> PyResult<String> {
        use star_rotk::components::{ActionPoints, SkillPoints};
        self.with_runtime(py, |r| {
            let ops: Vec<Value> =
                serde_json::from_str(&operations_json).map_err(|e| e.to_string())?;
            let mut results = Vec::new();
            for op in ops {
                let id = op["unit_id"].as_u64().ok_or("invalid unit_id")?;
                let entity = r.world.entity(id).ok_or("missing unit")?;
                let accepted = match op["kind"].as_str() {
                    Some("ap") => {
                        let mut ap = r
                            .world
                            .ecs
                            .get_mut::<ActionPoints>(entity)
                            .ok_or("missing AP")?;
                        let ok = ap.current_ap >= 1;
                        if ok {
                            ap.current_ap -= 1;
                        }
                        if ok {
                            r.mark_ap_spent(id);
                        }
                        ok
                    }
                    Some("skill") => {
                        let name = op["name"].as_str().ok_or("missing skill")?.to_string();
                        let cost = op["cost"].as_i64().ok_or("missing cost")?;
                        let cooldown = op["cooldown"].as_i64().ok_or("missing cooldown")?;
                        if cost < 0 || cooldown < 0 {
                            return Err("invalid skill probe".into());
                        }
                        let mut sp = r
                            .world
                            .ecs
                            .get_mut::<SkillPoints>(entity)
                            .ok_or("missing SP")?;
                        let ok = sp.current_sp >= cost
                            && sp.skill_cooldowns.get(&name).is_none_or(|v| *v <= 0);
                        if ok {
                            sp.current_sp -= cost;
                            if cooldown > 0 {
                                sp.skill_cooldowns.insert(name, cooldown);
                            }
                        }
                        if ok {
                            r.mark_skill_started(id);
                        }
                        ok
                    }
                    _ => return Err("unknown resource probe".into()),
                };
                if accepted {
                    r.revision = r.revision.checked_add(1).ok_or("revision exhausted")?;
                }
                results.push(accepted);
            }
            Ok(json!(results).to_string())
        })
    }
    /// Internal differential harness, never advertised as an Agent action gate.
    fn _movement_probe_json(&self, py: Python<'_>, operations_json: String) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let ops: Vec<Value> =
                serde_json::from_str(&operations_json).map_err(|e| e.to_string())?;
            let mut results = Vec::with_capacity(ops.len());
            for op in ops {
                let id = op["unit_id"].as_u64().ok_or("invalid unit_id")?;
                let kind = op["kind"].as_str().ok_or("missing kind")?;
                let result = if kind == "reachable" {
                    json!(r.reachable(id))
                } else {
                    let goal: (i64, i64) =
                        serde_json::from_value(op["goal"].clone()).map_err(|e| e.to_string())?;
                    if goal.0.unsigned_abs() > i32::MAX as u64
                        || goal.1.unsigned_abs() > i32::MAX as u64
                    {
                        return Err("probe coordinates exceed native range".into());
                    }
                    match kind {
                        "path" => json!(r.plan_path(id, goal, op["max_cost"].as_i64())),
                        "move" => {
                            let revision = r.revision.checked_add(1).ok_or("revision exhausted")?;
                            let result = r.move_unit(id, goal);
                            r.revision = revision;
                            result
                        }
                        _ => return Err("unknown movement probe".into()),
                    }
                };
                results.push(result);
            }
            Ok(json!(results).to_string())
        })
    }
    /// Diagnostic replay probe for the native RNG, not an Agent game verb.
    fn _rng_probe_json(
        &self,
        py: Python<'_>,
        domain: String,
        operations_json: String,
    ) -> PyResult<String> {
        self.with_runtime(py, |r| {
            let ops: Vec<Value> =
                serde_json::from_str(&operations_json).map_err(|e| e.to_string())?;
            // Work on a clone: invalid probe input cannot partly advance a stream.
            let mut rng = r.rng.trial(&domain);
            let mut results = Vec::with_capacity(ops.len());
            for op in ops {
                let value = match op["kind"].as_str() {
                    Some("random") => json!(rng.random()),
                    Some("bits") => {
                        let bits = op["bits"].as_u64().ok_or("missing bits")?;
                        if bits > 64 {
                            return Err("invalid bit width".into());
                        }
                        json!(rng.getrandbits(bits as u32)?)
                    }
                    Some("randbelow") => {
                        json!(rng.randbelow(op["n"].as_u64().ok_or("missing n")?)?)
                    }
                    Some("randint") => json!(rng.randint(
                        op["lo"].as_i64().ok_or("missing lo")?,
                        op["hi"].as_i64().ok_or("missing hi")?
                    )?),
                    Some("uniform") => json!(rng.uniform(
                        op["lo"].as_f64().ok_or("missing lo")?,
                        op["hi"].as_f64().ok_or("missing hi")?
                    )),
                    Some("shuffle") => {
                        let mut values = op["values"].as_array().ok_or("missing values")?.clone();
                        rng.shuffle(&mut values);
                        json!(values)
                    }
                    _ => return Err("unknown RNG probe operation".into()),
                };
                results.push(value);
            }
            let state = rng.state();
            r.rng.commit(domain, rng);
            Ok(json!({"results": results, "state": state}).to_string())
        })
    }
}

#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("API_VERSION", star_rotk::API_VERSION)?;
    m.add("RULES_VERSION", star_rotk::RULES_VERSION)?;
    m.add_class::<NativeRuntime>()?;
    Ok(())
}

thread_local! { static E8_FAIL_ENCODING: std::cell::Cell<bool> = const { std::cell::Cell::new(false) }; }
fn e8_encode<T: serde::Serialize>(response: &T) -> Result<String, serde_json::Error> {
    if E8_FAIL_ENCODING.with(|fault| fault.replace(false)) {
        return Err(serde_json::Error::io(std::io::Error::other("injected final encode fault")));
    }
    serde_json::to_string(response)
}
// Included in a diagnostic copy of the pinned PyO3 boundary, never the wheel.
#[cfg(test)]
mod e8_faults {
    use super::*;
    fn make(py: Python<'_>) -> NativeRuntime {
        NativeRuntime::new(py, include_str!("../initial.json").into(), 1).unwrap()
    }
    fn request(action: &str, parameters: Value, wall: f64) -> String {
        json!({"agent_id":"alpha", "action":action, "parameters":parameters,
            "wall_time":wall}).to_string()
    }
    fn query(wall: f64) -> String { request("get_faction_state", json!({"faction":"wei"}), wall) }
    fn compare(a: &NativeRuntime, b: &NativeRuntime) {
        let a = a.inner.lock().unwrap(); let b = b.inner.lock().unwrap();
        let a = a.runtime.as_ref().unwrap(); let b = b.runtime.as_ref().unwrap();
        assert_eq!(serde_json::to_value(a.export()).unwrap(), serde_json::to_value(b.export()).unwrap());
        assert_eq!(a.admitted_query_accounting_snapshot(Some("alpha")), b.admitted_query_accounting_snapshot(Some("alpha")));
    }
    #[test]
    fn exhausted_revision_preserves_release_prefix_and_invalidates() {
        Python::initialize(); Python::attach(|py| {
            let a=make(py); let b=make(py);
            let token=b._begin_observation_segment_json(py,"segment_encoded".into(),4,true).unwrap().unwrap();
            assert_eq!(a.execute_action_json(py,query(1.)).unwrap(),b._observation_segment_request_json(py,token.clone(),query(1.)).unwrap());
            for n in [&a,&b] { n.inner.lock().unwrap().runtime.as_mut().unwrap().revision=u64::MAX; }
            let unit: u64=37; // Frozen tiny fixture alpha claim.
            let bad=request("release_units",json!({"unit_ids":[unit,[1]]}),2.);
            for n in [&a,&b] { assert!(n.execute_action_json(py,bad.clone()).unwrap_err().to_string().contains("revision exhausted")); }
            assert!(b.inner.lock().unwrap().segment.is_none()); compare(&a,&b);
            let state=serde_json::to_value(a.inner.lock().unwrap().runtime.as_ref().unwrap().export()).unwrap();
            assert_eq!(state["singletons"]["TeamCoordination"]["unit_owners"],json!({}));
            assert_eq!(a.execute_action_json(py,query(3.)).unwrap(),b._observation_segment_request_json(py,token,query(3.)).unwrap());
            compare(&a,&b); a.close(py).unwrap(); b.close(py).unwrap();
        });
    }
    #[test]
    fn final_encoding_failure_preserves_commit_without_cache_or_retry() {
        Python::initialize(); Python::attach(|py| {
            let a=make(py); let b=make(py);
            let token=b._begin_observation_segment_json(py,"segment_encoded".into(),4,true).unwrap().unwrap();
            let owned=b._observation_segment_request_json(py,token.clone(),query(1.)).unwrap();
            assert_eq!(a.execute_action_json(py,query(1.)).unwrap(),owned);
            E8_FAIL_ENCODING.with(|fault| fault.set(true));
            assert!(a.execute_action_json(py,query(2.)).unwrap_err().to_string().contains("injected final encode fault"));
            E8_FAIL_ENCODING.with(|fault| fault.set(true));
            assert!(b._observation_segment_request_json(py,token.clone(),query(2.)).unwrap_err().to_string().contains("injected final encode fault"));
            assert!(b.inner.lock().unwrap().segment.is_none()); compare(&a,&b);
            assert_eq!(a.inner.lock().unwrap().runtime.as_ref().unwrap().admitted_query_accounting_snapshot(Some("alpha"))["agent_actions"],json!(2));
            let fresh=b._begin_observation_segment_json(py,"segment_encoded".into(),4,true).unwrap().unwrap();
            assert_eq!(a.execute_action_json(py,query(3.)).unwrap(),b._observation_segment_request_json(py,fresh.clone(),query(3.)).unwrap());
            let report: Value=serde_json::from_str(&b._end_observation_segment_json(py,fresh).unwrap().unwrap()).unwrap();
            assert_eq!(report["query_diagnostics"][0]["metrics"]["census_builds"],json!(1));
            assert_eq!(report["requests"],json!(1)); compare(&a,&b);
            a.close(py).unwrap(); b.close(py).unwrap();
            assert!(serde_json::from_str::<Value>(&owned).unwrap()["success"].as_bool().unwrap());
        });
    }
    #[test]
    fn generation_exhaustion_disables_cache_but_ordinary_request_survives() {
        Python::initialize(); Python::attach(|py| {
            let n=make(py); n.inner.lock().unwrap().generation=u64::MAX;
            assert!(n._begin_observation_segment_json(py,"segment_encoded".into(),4,true).unwrap_err().to_string().contains("generation exhausted"));
            assert!(n.inner.lock().unwrap().segment.is_none());
            assert!(serde_json::from_str::<Value>(&n.execute_action_json(py,query(1.)).unwrap()).unwrap()["success"].as_bool().unwrap());
            assert_eq!(n.inner.lock().unwrap().generation,u64::MAX);n.close(py).unwrap();
        });
    }
    #[test]
    fn repeated_segments_and_reset_keep_only_current_cache() {
        Python::initialize(); Python::attach(|py| {
            let n=make(py);let mut expected=None;
            for cycle in 0..64 {
                if cycle>0 && cycle%8==0 { n.reset(py,include_str!("../initial.json").into()).unwrap(); }
                let token=n._begin_observation_segment_json(py,"segment_encoded".into(),4,true).unwrap().unwrap();
                for i in 0..4 { n._observation_segment_request_json(py,token.clone(),query((cycle*4+i) as f64)).unwrap(); }
                let report: Value=serde_json::from_str(&n._end_observation_segment_json(py,token).unwrap().unwrap()).unwrap();
                assert_eq!(report["requests"],json!(4));
                assert_eq!(report["query_diagnostics"][0]["metrics"]["census_builds"],json!(1));
                for i in 1..4 { assert_eq!(report["query_diagnostics"][i]["metrics"]["census_builds"],json!(0)); }
                let summary=report["cache_before_drop"].clone();
                if let Some(ref old)=expected { assert_eq!(&summary,old); } else { expected=Some(summary); }
                assert!(n.inner.lock().unwrap().segment.is_none());
            }
            n.close(py).unwrap();let state=n.inner.lock().unwrap();
            assert!(state.segment.is_none() && state.runtime.is_none());
        });
    }
}
