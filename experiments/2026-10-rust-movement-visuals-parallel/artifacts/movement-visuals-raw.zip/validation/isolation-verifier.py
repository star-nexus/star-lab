import subprocess,json,hashlib
from pathlib import Path
roots=dict(original='/Users/liyang/Developer/star-main',active='/Users/liyang/.codex/worktrees/rust-ecs-parallel/star-main',frozen_rust='/Users/liyang/.codex/worktrees/rust-wire-observation/star-main',frozen_python='/Users/liyang/.codex/worktrees/python-capacity-baseline/star-main')
r={}
for key,path in roots.items():
    git=lambda *a:subprocess.check_output(['git','-C',path,*a],text=True)
    status=git('status','--porcelain');r[key]=dict(path=path,head=git('rev-parse','HEAD').strip(),status=status)
    if key=='original':assert len(status.splitlines())==49 and all(x.startswith(' D ') for x in status.splitlines()) and r[key]['head']=='7e145d169433695cd4957e186a6b2fda06813c26'
    else:assert not status
assert r['active']['head']=='3b167b151c3bc32e1d54f6015d0f15d2c3dd6a74'
assert r['frozen_rust']['head']=='5147e4d8e0c33c997bd86960d87fa4b5b3ca90c5'
assert r['frozen_python']['head']=='6a970deaee7d9b8d3939edd102973f2377edd6ac'
so=next((Path(roots['frozen_rust'])/'.venv/lib/python3.13/site-packages/star_native').glob('*.so'))
r['frozen_rust']['extension_sha256']=hashlib.sha256(so.read_bytes()).hexdigest();assert r['frozen_rust']['extension_sha256']=='324454a00ab8bd3559c9229e6c6c9644242d65c488585eba7d29a63b39d29405'
r['tags']={tag:subprocess.check_output(['git','-C',roots['active'],'rev-parse',tag+'^{}'],text=True).strip() for tag in ['rust-parallel-e2-statistics-2026-10-01','rust-parallel-e3-internal-attribution-2026-10-01','rust-parallel-e4-dispatch-screen-2026-10-02','rust-parallel-e5-movement-visuals-2026-10-02']}
assert r['tags']['rust-parallel-e2-statistics-2026-10-01']=='0aa28ac2ae0267048fcdb3998f9d76175ed4d699'
assert r['tags']['rust-parallel-e3-internal-attribution-2026-10-01']=='6d4018cc0c607a51a3783428867ba9259bb43f43'
Path('/Users/liyang/Developer/star-lab/experiments/2026-10-rust-movement-visuals-parallel/results/isolation.json').write_text(json.dumps(r,indent=2)+'\n')
print('Original49/frozen HEADs and extension/active clean/tags verified')
