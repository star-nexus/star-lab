import json,time
from pathlib import Path
for i in range(40):
 Path('/Users/liyang/Developer/star-lab-runs/e7-p2-20261007-pause-only-control/count').write_text(str(i))
 print(json.dumps(dict(progress=i)),flush=True)
 time.sleep(.05)
