from pathlib import Path
import json,gzip
lab=Path('/Users/liyang/Developer/star-lab');run=lab/'runs/ecs-e5';exp=lab/'experiments/2026-10-rust-movement-visuals-parallel';r=json.loads((run/'analysis.json').read_text())
assert len(r['identity_checks'])==27 and r['primary_gates']=={'2':False,'4':False}
primary=[v for v in r['results'] if v['run'].startswith('primary-')]
def table(rows):
 out=['| 对照 | Mean 改善 | CI95改善（µs） | P99对照 → parallel（µs） | 门槛 |','|---|---:|---:|---:|---|']
 for v in rows:out.append(f"| {v['run'].removesuffix('.json')} | {v['improvement_percent']:.3f}% | [{v['ci95_ns'][0]/1000:.3f}, {v['ci95_ns'][1]/1000:.3f}] | {v['baseline']['p99_ns']/1000:.3f} → {v['candidate']['p99_ns']/1000:.3f} | {'PASS' if v['passed'] else 'FAIL'} |")
 return '\n'.join(out)
# Compare diagnostic costs on the SAME recorded candidate tick mask. Actual
# dispatch count remains separate: baseline has no dispatch and no preparation.
matched=[]
for t in [2,4]:
 def load(mode):return json.loads(gzip.decompress((run/f'replays/diagnostic-{mode}-t{t}.timings.json.gz').read_bytes()))
 par=load('parallel');mask={x['seq'] for x in par if x['phases_ns'].get('e5_eligible')};assert len(mask)==3772
 for mode in ['baseline','empty_fork','split_serial','parallel']:
  rows=[x for x in load(mode) if x['seq'] in mask];assert len(rows)==3772
  fields={key:sum(x['phases_ns'].get(key,0) for x in rows)/len(rows) for key in ['e5_prepare','movement','visuals','e5_compute','e5_publish','e5_region']}
  matched.append(dict(threads=t,mode=mode,matched_ticks=len(rows),actual_selected_ticks=sum(x['phases_ns'].get('e5_eligible',0) for x in rows),means_ns=fields))
(exp/'results/matched-diagnostic-costs.json').write_text(json.dumps(dict(results=matched,scope='same recorded tick mask, different diagnostic runs; includes nested clocks, not an untimed speedup'),indent=2)+'\n')
diag=['| Threads / 模式 | Prepare | Movement | Visuals / Compute | Publish | Region |','|---|---:|---:|---:|---:|---:|']
for d in matched:
 v=d['means_ns'];diag.append(f"| {d['threads']} / {d['mode']} | {v['e5_prepare']/1000:.3f} | {v['movement']/1000:.3f} | {(v['visuals']+v['e5_compute'])/1000:.3f} | {v['e5_publish']/1000:.3f} | {v['e5_region']/1000:.3f} |")
evidence='主门槛，正值表示parallel更快，负值表示更慢：\n\n'+table(primary)+'\n\n拆分对照（均为门槛8）：\n\n'+table([v for v in r['results'] if v['run'].startswith('split-control')])+'\n\n单轮敏感性（不作为生产选择）：\n\n'+table([v for v in r['results'] if v['run'].startswith('sensitivity')])+'\n\n四模式共同3772-tick掩码诊断（µs）：\n\n'+'\n'.join(diag)+'\n\nRegion包含Movement和Compute，不能相加。native2/4的parallel计时区间交叠下界均值为16.917/15.769µs，3758/3761个候选tick下界>0。它包含嵌套时钟及OS时间，不是纯CPU计算收益；跨诊断run的成本差也不能解释为精确因果净收益。'
p=exp/'analysis.md';s=p.read_text().replace('TODO_FINAL_RESULTS',evidence).replace('TODO_FINAL_CAUSE','已证实：窄输入和所有权计划允许两个System的计算区间安全重叠，完整规则/错误前缀等价；当前轨迹下门槛8在native2/4均只1/3主轮通过，未获得满足预设门槛的可重复完整step净收益。六组敏感性全部CI95跨零，不能找到经过确认的替代阈值。具体调度/核心/allocator噪声占比没有被隔离，因此不宣称它们是已确认根因，也不宣称无诊断并行必然负收益。');p.write_text(s)
p=exp/'decision.md';s=p.read_text().replace('**Status:** pending','**Status:** accepted — negative adoption result').replace('TODO_FINAL_DECISION','完成四模式原型和研究，保留私有按次接口，普通step不启用E5。native2/4三轮主对照均仅一轮完整通过；0/4/16六个单轮敏感性均未通过。native4未通过前置门槛，因此不进入单实例ABBA确认或实际窗口验收；此停止符合预注册计划。机制验证成功，但没有稳定净收益证据，不外推所有System之间并行无价值。');p.write_text(s)
p=exp/'README.md';s=p.read_text().replace('状态：主收益研究已完成，native2/4均未通过稳定门槛；正在补齐诊断、敏感性及正式归档。无默认接入或容量结论。','状态：E5研究完成。安全重叠机制及四模式验证通过；native2/4均未通过稳定净收益门槛，普通step不启用E5，无新live/容量结论。')
s=s.replace('## 恢复与复算','## 通俗结论\n\n让Visuals在后台计算、同时让主线程推进Movement，确实能同时做事，而且没有改变游戏状态、展示或错误顺序；但每tick可重叠的工作较小，完整step收益在不同轮次不够稳定。2/4线程都只有一轮达到预设门槛，其他门槛的单轮信号也未被置信区间确认，所以保留研究接口、默认继续原序执行。此结论限定本机、当前5000Units/1000Agents轨迹和本轮方案，不代表所有System并行方案都无价值。\n\n进度：`依赖/窄接口 █ | 四模式/等价 █ | 净收益/敏感性 █ | 条件停止/决策 █ | 归档/校验 █`。\n\n## 恢复与复算',1)
p.write_text(s)
print('Final tables, decision, diagnostic tick matching complete')
